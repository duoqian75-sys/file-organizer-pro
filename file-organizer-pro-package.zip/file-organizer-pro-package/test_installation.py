#!/usr/bin/env python3
"""
安装测试脚本
验证文件整理助手是否正确安装
"""

import os
import sys
from pathlib import Path

def check_python_version():
    """检查Python版本"""
    print("检查Python版本...")
    version = sys.version_info
    if version.major >= 3 and version.minor >= 8:
        print(f"  ✓ Python {version.major}.{version.minor}.{version.micro} 符合要求")
        return True
    else:
        print(f"  ✗ Python {version.major}.{version.minor}.{version.micro} 不符合要求")
        print("  需要 Python 3.8+")
        return False

def check_required_files():
    """检查必需文件"""
    print("\n检查必需文件...")
    
    required_files = [
        "SKILL.md",
        "INSTALL.md", 
        "README.md",
        "scripts/organize_by_type.py",
        "scripts/clean_temporary.py",
        "scripts/find_duplicates.py",
        "scripts/batch_rename.py",
        "references/file_types.md",
        "references/usage_guide.md",
        "references/config_example.yaml"
    ]
    
    all_exist = True
    for file_path in required_files:
        if Path(file_path).exists():
            print(f"  ✓ {file_path}")
        else:
            print(f"  ✗ {file_path} 缺失")
            all_exist = False
    
    return all_exist

def check_python_scripts():
    """检查Python脚本语法"""
    print("\n检查Python脚本语法...")
    
    scripts = [
        "scripts/organize_by_type.py",
        "scripts/clean_temporary.py", 
        "scripts/find_duplicates.py",
        "scripts/batch_rename.py"
    ]
    
    all_valid = True
    for script in scripts:
        try:
            with open(script, 'r', encoding='utf-8') as f:
                # 简单检查文件头
                content = f.read(100)
                if 'python' in content.lower() or '#!/usr' in content:
                    print(f"  ✓ {script} 格式正确")
                else:
                    print(f"  ⚠ {script} 格式可能有问题")
        except Exception as e:
            print(f"  ✗ {script} 读取失败: {e}")
            all_valid = False
    
    return all_valid

def check_dependencies():
    """检查依赖"""
    print("\n检查依赖...")
    
    try:
        import send2trash
        print("  ✓ send2trash 已安装")
        send2trash_installed = True
    except ImportError:
        print("  ⚠ send2trash 未安装（可选）")
        print("    安装命令: pip install send2trash")
        send2trash_installed = False
    
    return send2trash_installed

def run_quick_test():
    """运行快速测试"""
    print("\n运行快速测试...")
    
    test_dir = Path("test_installation")
    test_dir.mkdir(exist_ok=True)
    
    # 创建测试文件
    test_files = [
        test_dir / "test1.txt",
        test_dir / "test2.txt", 
        test_dir / "test3.log",
        test_dir / "image1.jpg",
        test_dir / "document1.pdf"
    ]
    
    for file in test_files:
        file.write_text(f"Test content for {file.name}")
    
    print(f"  ✓ 创建了 {len(test_files)} 个测试文件")
    
    # 清理测试文件
    import shutil
    shutil.rmtree(test_dir)
    print("  ✓ 清理测试文件")
    
    return True

def main():
    print("=" * 60)
    print("文件整理助手专业版 - 安装测试")
    print("=" * 60)
    
    results = []
    
    # 运行检查
    results.append(("Python版本", check_python_version()))
    results.append(("必需文件", check_required_files()))
    results.append(("脚本语法", check_python_scripts()))
    results.append(("依赖检查", check_dependencies()))
    results.append(("快速测试", run_quick_test()))
    
    print("\n" + "=" * 60)
    print("测试结果汇总:")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for name, success in results:
        status = "✓ 通过" if success else "✗ 失败"
        print(f"{name:15} {status}")
        if success:
            passed += 1
    
    print("=" * 60)
    
    if passed == total:
        print(f"🎉 所有测试通过 ({passed}/{total})")
        print("\n安装成功！可以开始使用文件整理助手了。")
        print("\n快速开始:")
        print("  python scripts/organize_by_type.py --help")
        print("  python scripts/clean_temporary.py --dry-run")
    else:
        print(f"⚠  {passed}/{total} 项测试通过")
        print("\n安装存在问题，请根据上面的提示修复。")
    
    print("\n详细使用说明请查看:")
    print("  README.md - 基本使用")
    print("  INSTALL.md - 安装指南")
    print("  references/usage_guide.md - 使用指南")

if __name__ == "__main__":
    main()