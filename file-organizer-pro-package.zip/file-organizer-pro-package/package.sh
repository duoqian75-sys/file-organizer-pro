#!/bin/bash
# 文件整理助手专业版 - 打包脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 版本信息
VERSION="1.0.0"
PACKAGE_NAME="file-organizer-pro-v${VERSION}"
OUTPUT_DIR="dist"
ZIP_FILE="${OUTPUT_DIR}/${PACKAGE_NAME}.zip"

echo -e "${GREEN}文件整理助手专业版 - 打包工具${NC}"
echo -e "版本: ${VERSION}"
echo ""

# 检查目录是否存在
if [ ! -d "file-organizer-pro-package" ]; then
    echo -e "${RED}错误: file-organizer-pro-package 目录不存在${NC}"
    echo "请先运行创建技能包的脚本"
    exit 1
fi

# 创建输出目录
mkdir -p "${OUTPUT_DIR}"

echo -e "${YELLOW}步骤1: 检查文件完整性...${NC}"

# 检查必需文件
required_files=(
    "SKILL.md"
    "INSTALL.md"
    "README.md"
    "scripts/organize_by_type.py"
    "scripts/clean_temporary.py"
    "scripts/find_duplicates.py"
    "scripts/batch_rename.py"
    "references/file_types.md"
    "references/usage_guide.md"
    "references/config_example.yaml"
)

missing_files=()
for file in "${required_files[@]}"; do
    if [ ! -f "file-organizer-pro-package/${file}" ]; then
        missing_files+=("${file}")
    fi
done

if [ ${#missing_files[@]} -gt 0 ]; then
    echo -e "${RED}错误: 以下必需文件缺失:${NC}"
    for file in "${missing_files[@]}"; do
        echo "  - ${file}"
    done
    exit 1
fi

echo -e "${GREEN}✓ 所有必需文件存在${NC}"

# 检查Python脚本语法
echo -e "${YELLOW}步骤2: 检查Python脚本语法...${NC}"

python_scripts=(
    "scripts/organize_by_type.py"
    "scripts/clean_temporary.py"
    "scripts/find_duplicates.py"
    "scripts/batch_rename.py"
)

for script in "${python_scripts[@]}"; do
    if python3 -m py_compile "file-organizer-pro-package/${script}" 2>/dev/null; then
        echo -e "${GREEN}✓ ${script} 语法正确${NC}"
    else
        echo -e "${RED}✗ ${script} 语法错误${NC}"
        exit 1
    fi
done

# 创建临时打包目录
echo -e "${YELLOW}步骤3: 创建打包目录...${NC}"
TEMP_DIR=$(mktemp -d)
cp -r "file-organizer-pro-package" "${TEMP_DIR}/${PACKAGE_NAME}"

# 添加版本文件
echo "${VERSION}" > "${TEMP_DIR}/${PACKAGE_NAME}/VERSION.txt"
date "+%Y-%m-%d %H:%M:%S" > "${TEMP_DIR}/${PACKAGE_NAME}/BUILD_DATE.txt"

# 创建压缩包
echo -e "${YELLOW}步骤4: 创建压缩包...${NC}"
cd "${TEMP_DIR}"
if zip -rq "${OLDPWD}/${ZIP_FILE}" "${PACKAGE_NAME}"; then
    echo -e "${GREEN}✓ 压缩包创建成功: ${ZIP_FILE}${NC}"
else
    echo -e "${RED}✗ 压缩包创建失败${NC}"
    exit 1
fi
cd "${OLDPWD}"

# 清理临时目录
rm -rf "${TEMP_DIR}"

# 计算文件大小
FILE_SIZE=$(du -h "${ZIP_FILE}" | cut -f1)
echo -e "${YELLOW}步骤5: 生成校验文件...${NC}"

# 生成MD5校验和
md5sum "${ZIP_FILE}" > "${ZIP_FILE}.md5"
echo -e "${GREEN}✓ MD5校验和生成成功${NC}"

# 生成SHA256校验和
sha256sum "${ZIP_FILE}" > "${ZIP_FILE}.sha256"
echo -e "${GREEN}✓ SHA256校验和生成成功${NC}"

# 显示打包结果
echo ""
echo -e "${GREEN}══════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}打包完成！${NC}"
echo ""
echo -e "📦 包名称: ${PACKAGE_NAME}.zip"
echo -e "📏 文件大小: ${FILE_SIZE}"
echo -e "📁 输出目录: ${OUTPUT_DIR}/"
echo ""
echo -e "📋 包含文件:"
echo "  ├── SKILL.md                    # 技能文档"
echo "  ├── INSTALL.md                  # 安装指南"
echo "  ├── README.md                   # 使用说明"
echo "  ├── scripts/                    # 脚本目录"
echo "  │   ├── organize_by_type.py     # 按类型整理"
echo "  │   ├── clean_temporary.py      # 清理临时文件"
echo "  │   ├── find_duplicates.py      # 查找重复文件"
echo "  │   └── batch_rename.py         # 批量重命名"
echo "  ├── references/                 # 参考文档"
echo "  │   ├── file_types.md           # 文件类型参考"
echo "  │   ├── usage_guide.md          # 使用指南"
echo "  │   └── config_example.yaml     # 配置文件示例"
echo "  ├── VERSION.txt                 # 版本信息"
echo "  └── BUILD_DATE.txt              # 构建日期"
echo ""
echo -e "🔒 校验文件:"
echo "  ├── ${PACKAGE_NAME}.zip.md5"
echo "  └── ${PACKAGE_NAME}.zip.sha256"
echo ""
echo -e "🚀 使用说明:"
echo "  1. 解压 ${ZIP_FILE}"
echo "  2. 阅读 INSTALL.md 安装指南"
echo "  3. 按照 README.md 开始使用"
echo ""
echo -e "💡 提示: 可以使用以下命令验证文件完整性:"
echo "  md5sum -c ${ZIP_FILE}.md5"
echo "  sha256sum -c ${ZIP_FILE}.sha256"
echo -e "${GREEN}══════════════════════════════════════════════════════════════${NC}"

# 创建Windows批处理打包脚本
cat > "${OUTPUT_DIR}/package.bat" << 'EOF'
@echo off
chcp 65001 >nul
echo 文件整理助手专业版 - Windows打包工具
echo.

REM 检查7-Zip
where 7z >nul 2>nul
if %errorlevel% neq 0 (
    echo 错误: 需要安装7-Zip
    echo 请从 https://www.7-zip.org/ 下载安装
    pause
    exit /b 1
)

REM 设置变量
set VERSION=1.0.0
set PACKAGE_NAME=file-organizer-pro-v%VERSION%
set OUTPUT_DIR=dist

REM 创建输出目录
if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"

REM 检查源目录
if not exist "file-organizer-pro-package" (
    echo 错误: file-organizer-pro-package 目录不存在
    pause
    exit /b 1
)

REM 创建压缩包
echo 正在创建压缩包...
7z a -tzip "%OUTPUT_DIR%\%PACKAGE_NAME%.zip" "file-organizer-pro-package\*" -r >nul

if %errorlevel% equ 0 (
    echo 压缩包创建成功: %OUTPUT_DIR%\%PACKAGE_NAME%.zip
) else (
    echo 压缩包创建失败
    pause
    exit /b 1
)

REM 生成版本文件
echo %VERSION% > "%OUTPUT_DIR%\VERSION.txt"
echo %date% %time% > "%OUTPUT_DIR%\BUILD_DATE.txt"

echo.
echo 打包完成！
echo.
echo 文件: %OUTPUT_DIR%\%PACKAGE_NAME%.zip
echo 版本: %VERSION%
echo.
pause
EOF

echo -e "${GREEN}✓ Windows打包脚本已生成: ${OUTPUT_DIR}/package.bat${NC}"

echo ""
echo -e "${YELLOW}下一步:${NC}"
echo "1. 分享 ${ZIP_FILE} 给其他人使用"
echo "2. 上传到GitHub或其他代码托管平台"
echo "3. 创建发布页面和下载链接"
echo "4. 收集用户反馈并改进"