#!/usr/bin/env python3
"""
按文件类型整理脚本
"""

import os
import shutil
from pathlib import Path

def organize_by_type(directory="."):
    """按文件类型整理文件"""
    directory = Path(directory)
    
    # 文件类型分类
    categories = {
        "images": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp"],
        "documents": [".pdf", ".doc", ".docx", ".txt", ".md", ".rtf"],
        "code": [".py", ".js", ".html", ".css", ".json", ".xml", ".yml", ".yaml"],
        "archives": [".zip", ".rar", ".7z", ".tar", ".gz"],
        "data": [".csv", ".xlsx", ".xls", ".db", ".sqlite"],
        "media": [".mp3", ".mp4", ".avi", ".mov", ".wav"]
    }
    
    # 创建分类文件夹
    for category in categories.keys():
        (directory / category).mkdir(exist_ok=True)
    
    # 整理文件
    for file_path in directory.iterdir():
        if file_path.is_file():
            ext = file_path.suffix.lower()
            moved = False
            
            for category, extensions in categories.items():
                if ext in extensions:
                    target_dir = directory / category
                    try:
                        shutil.move(str(file_path), str(target_dir / file_path.name))
                        print(f"移动: {file_path.name} -> {category}/")
                        moved = True
                        break
                    except Exception as e:
                        print(f"移动失败 {file_path.name}: {e}")
            
            if not moved:
                # 未分类文件
                other_dir = directory / "other"
                other_dir.mkdir(exist_ok=True)
                try:
                    shutil.move(str(file_path), str(other_dir / file_path.name))
                    print(f"移动: {file_path.name} -> other/")
                except Exception as e:
                    print(f"移动失败 {file_path.name}: {e}")

if __name__ == "__main__":
    organize_by_type()