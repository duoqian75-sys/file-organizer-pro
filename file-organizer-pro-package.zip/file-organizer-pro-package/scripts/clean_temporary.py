#!/usr/bin/env python3
"""
清理临时文件脚本
"""

import os
import shutil
from pathlib import Path
import time
from datetime import datetime, timedelta

def clean_temporary_files(directory=".", days_old=30, dry_run=False):
    """
    清理临时文件
    
    Args:
        directory: 要清理的目录
        days_old: 清理多少天前的文件
        dry_run: 预览模式，不实际删除
    """
    directory = Path(directory)
    
    # 临时文件扩展名
    temp_extensions = [
        '.tmp', '.temp', '.cache', '.log',
        '.swp', '.swo', '.swn',  # Vim临时文件
        '~', '.bak', '.backup',  # 备份文件
        '.DS_Store', 'Thumbs.db'  # 系统文件
    ]
    
    # 临时文件名模式
    temp_patterns = [
        'temp_', 'tmp_', 'cache_',
        '~$', '._'  # Office临时文件
    ]
    
    # 计算截止日期
    cutoff_date = datetime.now() - timedelta(days=days_old)
    
    files_to_delete = []
    total_size = 0
    
    print(f"扫描目录: {directory.absolute()}")
    print(f"清理 {days_old} 天前的临时文件")
    print(f"预览模式: {'是' if dry_run else '否'}")
    print("-" * 60)
    
    # 递归扫描文件
    for file_path in directory.rglob('*'):
        if file_path.is_file():
            # 检查文件扩展名
            ext = file_path.suffix.lower()
            filename = file_path.name
            
            # 检查是否临时文件
            is_temp = False
            reason = ""
            
            # 检查扩展名
            if ext in temp_extensions:
                is_temp = True
                reason = f"临时扩展名: {ext}"
            
            # 检查文件名模式
            elif any(pattern in filename for pattern in temp_patterns):
                is_temp = True
                reason = f"临时文件名模式"
            
            # 检查文件时间
            if is_temp:
                try:
                    mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
                    if mtime < cutoff_date:
                        file_size = file_path.stat().st_size
                        files_to_delete.append({
                            'path': file_path,
                            'size': file_size,
                            'reason': reason,
                            'mtime': mtime
                        })
                        total_size += file_size
                except (OSError, PermissionError):
                    continue
    
    # 显示结果
    if not files_to_delete:
        print("未找到符合条件的临时文件")
        return
    
    print(f"找到 {len(files_to_delete)} 个临时文件，总计 {total_size / 1024 / 1024:.2f} MB")
    print("\n文件列表:")
    print("-" * 80)
    
    for i, file_info in enumerate(files_to_delete, 1):
        path = file_info['path']
        size_mb = file_info['size'] / 1024 / 1024
        mtime = file_info['mtime'].strftime('%Y-%m-%d %H:%M')
        
        print(f"{i:3d}. {path.relative_to(directory)}")
        print(f"     大小: {size_mb:.2f} MB | 修改时间: {mtime} | 原因: {file_info['reason']}")
    
    print("-" * 80)
    
    if dry_run:
        print(f"预览模式: 将删除 {len(files_to_delete)} 个文件，释放 {total_size / 1024 / 1024:.2f} MB 空间")
        print("使用 --execute 参数实际执行删除")
        return
    
    # 确认删除
    print(f"\n确认删除 {len(files_to_delete)} 个文件，释放 {total_size / 1024 / 1024:.2f} MB 空间？")
    response = input("输入 'yes' 确认删除，其他任意键取消: ").strip().lower()
    
    if response != 'yes':
        print("操作已取消")
        return
    
    # 执行删除
    deleted_count = 0
    deleted_size = 0
    
    for file_info in files_to_delete:
        try:
            file_path = file_info['path']
            file_size = file_info['size']
            
            # 尝试删除到回收站
            try:
                # Windows: 使用send2trash
                import send2trash
                send2trash.send2trash(str(file_path))
            except ImportError:
                # 备用方案：直接删除
                file_path.unlink()
            
            deleted_count += 1
            deleted_size += file_size
            print(f"已删除: {file_path.relative_to(directory)}")
            
        except (OSError, PermissionError) as e:
            print(f"删除失败 {file_path.relative_to(directory)}: {e}")
    
    print(f"\n操作完成!")
    print(f"已删除 {deleted_count}/{len(files_to_delete)} 个文件")
    print(f"释放空间: {deleted_size / 1024 / 1024:.2f} MB")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="清理临时文件")
    parser.add_argument("directory", nargs="?", default=".", help="要清理的目录")
    parser.add_argument("--days", type=int, default=30, help="清理多少天前的文件（默认: 30）")
    parser.add_argument("--dry-run", action="store_true", help="预览模式，不实际删除")
    parser.add_argument("--execute", action="store_true", help="实际执行删除")
    
    args = parser.parse_args()
    
    # 如果指定了--execute，则关闭dry_run
    dry_run = args.dry_run and not args.execute
    
    clean_temporary_files(args.directory, args.days, dry_run)