#!/usr/bin/env python3
"""
查找重复文件脚本
"""

import os
import hashlib
from pathlib import Path
from collections import defaultdict
import argparse

def get_file_hash(filepath, chunk_size=8192):
    """计算文件的MD5哈希值"""
    hash_md5 = hashlib.md5()
    
    try:
        with open(filepath, "rb") as f:
            for chunk in iter(lambda: f.read(chunk_size), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()
    except (OSError, PermissionError):
        return None

def find_duplicate_files(directory=".", min_size_kb=10, recursive=True):
    """
    查找重复文件
    
    Args:
        directory: 要扫描的目录
        min_size_kb: 最小文件大小（KB），小于此大小的文件忽略
        recursive: 是否递归扫描子目录
    """
    directory = Path(directory)
    
    print(f"扫描目录: {directory.absolute()}")
    print(f"最小文件大小: {min_size_kb} KB")
    print(f"递归扫描: {'是' if recursive else '否'}")
    print("-" * 60)
    
    # 按大小分组文件
    size_groups = defaultdict(list)
    
    # 扫描文件
    scan_pattern = directory.rglob('*') if recursive else directory.glob('*')
    
    for file_path in scan_pattern:
        if file_path.is_file():
            try:
                file_size = file_path.stat().st_size
                
                # 忽略太小的文件
                if file_size < min_size_kb * 1024:
                    continue
                
                size_groups[file_size].append(file_path)
                
            except (OSError, PermissionError):
                continue
    
    print(f"扫描完成，找到 {sum(len(files) for files in size_groups.values())} 个文件")
    print(f"按大小分组: {len(size_groups)} 组")
    
    # 查找可能重复的文件（大小相同的文件）
    potential_duplicates = {size: files for size, files in size_groups.items() if len(files) > 1}
    
    if not potential_duplicates:
        print("\n未找到可能重复的文件")
        return {}
    
    print(f"\n找到 {len(potential_duplicates)} 组大小相同的文件")
    
    # 计算哈希值确认重复
    duplicate_groups = defaultdict(list)
    processed_count = 0
    
    for size, file_list in potential_duplicates.items():
        hash_groups = defaultdict(list)
        
        for file_path in file_list:
            file_hash = get_file_hash(file_path)
            if file_hash:
                hash_groups[file_hash].append(file_path)
        
        # 只保留哈希值相同的组（真正的重复文件）
        for file_hash, hash_file_list in hash_groups.items():
            if len(hash_file_list) > 1:
                duplicate_groups[file_hash] = hash_file_list
        
        processed_count += 1
        if processed_count % 10 == 0:
            print(f"处理进度: {processed_count}/{len(potential_duplicates)} 组")
    
    return duplicate_groups

def display_duplicates(duplicate_groups, directory):
    """显示重复文件结果"""
    if not duplicate_groups:
        print("\n未找到重复文件")
        return
    
    total_duplicates = sum(len(files) - 1 for files in duplicate_groups.values())
    total_space = 0
    
    print(f"\n找到 {len(duplicate_groups)} 组重复文件，共 {total_duplicates} 个重复副本")
    print("=" * 80)
    
    for i, (file_hash, file_list) in enumerate(duplicate_groups.items(), 1):
        # 计算这组文件的总空间浪费
        file_size = file_list[0].stat().st_size
        wasted_space = file_size * (len(file_list) - 1)
        total_space += wasted_space
        
        print(f"\n第 {i} 组 - 哈希: {file_hash[:8]}...")
        print(f"文件大小: {file_size / 1024:.2f} KB")
        print(f"重复数量: {len(file_list)} 个副本")
        print(f"浪费空间: {wasted_space / 1024:.2f} KB")
        print("-" * 40)
        
        for j, file_path in enumerate(file_list, 1):
            rel_path = file_path.relative_to(directory)
            mtime = file_path.stat().st_mtime
            print(f"  {j}. {rel_path}")
            print(f"     修改时间: {mtime}")
        
        print("-" * 40)
        
        # 建议保留的文件（通常是修改时间最新的）
        keep_file = max(file_list, key=lambda p: p.stat().st_mtime)
        print(f"建议保留: {keep_file.relative_to(directory)} (最新修改)")
    
    print("=" * 80)
    print(f"总计浪费空间: {total_space / 1024 / 1024:.2f} MB")
    print(f"可释放空间: {total_space / 1024 / 1024:.2f} MB (删除所有重复副本)")
    
    return total_space

def generate_cleanup_script(duplicate_groups, directory, output_file="cleanup_duplicates.sh"):
    """生成清理脚本"""
    if not duplicate_groups:
        print("没有重复文件，无需生成清理脚本")
        return
    
    script_content = "#!/bin/bash\n"
    script_content += "# 重复文件清理脚本\n"
    script_content += "# 生成时间: " + str(datetime.now()) + "\n"
    script_content += f"# 目录: {directory}\n\n"
    
    script_content += "echo '开始清理重复文件...'\n\n"
    
    for file_hash, file_list in duplicate_groups.items():
        # 保留修改时间最新的文件
        keep_file = max(file_list, key=lambda p: p.stat().st_mtime)
        
        script_content += f"# 第 {file_hash[:8]}... 组\n"
        script_content += f"echo '处理哈希: {file_hash[:8]}...'\n"
        
        for file_path in file_list:
            if file_path != keep_file:
                rel_path = file_path.relative_to(directory)
                script_content += f"rm -f \"{rel_path}\"\n"
                script_content += f"echo '  删除: {rel_path}'\n"
        
        script_content += "echo ''\n"
    
    script_content += "\necho '清理完成!'\n"
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(script_content)
    
    print(f"\n清理脚本已生成: {output_file}")
    print("请检查脚本内容后执行: bash cleanup_duplicates.sh")

if __name__ == "__main__":
    import sys
    from datetime import datetime
    
    parser = argparse.ArgumentParser(description="查找重复文件")
    parser.add_argument("directory", nargs="?", default=".", help="要扫描的目录")
    parser.add_argument("--min-size", type=int, default=10, help="最小文件大小(KB)，默认: 10")
    parser.add_argument("--no-recursive", action="store_true", help="不递归扫描子目录")
    parser.add_argument("--generate-script", action="store_true", help="生成清理脚本")
    
    args = parser.parse_args()
    
    recursive = not args.no_recursive
    
    duplicates = find_duplicate_files(args.directory, args.min_size, recursive)
    
    if duplicates:
        wasted_space = display_duplicates(duplicates, Path(args.directory))
        
        if args.generate_script:
            generate_cleanup_script(duplicates, Path(args.directory))
        
        print("\n操作建议:")
        print("1. 手动检查重复文件，确认可以删除")
        print("2. 备份重要文件后再删除")
        print("3. 可以使用生成的清理脚本批量删除")
    else:
        print("\n恭喜！没有找到重复文件")