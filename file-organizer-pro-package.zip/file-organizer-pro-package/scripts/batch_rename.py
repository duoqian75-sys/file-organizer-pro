#!/usr/bin/env python3
"""
批量重命名脚本
"""

import os
import re
from pathlib import Path
import argparse
from datetime import datetime

class BatchRenamer:
    """批量重命名器"""
    
    def __init__(self, directory="."):
        self.directory = Path(directory)
        self.operations = []
    
    def find_files(self, pattern="*", recursive=False):
        """查找匹配模式的文件"""
        if recursive:
            return list(self.directory.rglob(pattern))
        else:
            return list(self.directory.glob(pattern))
    
    def preview_rename(self, files, new_name_pattern, start_index=1):
        """预览重命名操作"""
        operations = []
        
        for i, file_path in enumerate(files, start_index):
            # 生成新文件名
            new_name = self._generate_new_name(new_name_pattern, file_path, i)
            new_path = file_path.parent / new_name
            
            operations.append({
                'old_path': file_path,
                'new_path': new_path,
                'old_name': file_path.name,
                'new_name': new_name
            })
        
        return operations
    
    def _generate_new_name(self, pattern, file_path, index):
        """根据模式生成新文件名"""
        # 获取文件信息
        stem = file_path.stem
        ext = file_path.suffix
        parent = file_path.parent.name
        
        # 当前时间
        now = datetime.now()
        
        # 替换模式中的变量
        new_name = pattern
        
        # 日期时间变量
        new_name = new_name.replace('{YYYY}', now.strftime('%Y'))
        new_name = new_name.replace('{MM}', now.strftime('%m'))
        new_name = new_name.replace('{DD}', now.strftime('%d'))
        new_name = new_name.replace('{HH}', now.strftime('%H'))
        new_name = new_name.replace('{mm}', now.strftime('%M'))
        new_name = new_name.replace('{SS}', now.strftime('%S'))
        
        # 文件信息变量
        new_name = new_name.replace('{INDEX}', f"{index:03d}")
        new_name = new_name.replace('{INDEX1}', f"{index}")
        new_name = new_name.replace('{STEM}', stem)
        new_name = new_name.replace('{EXT}', ext[1:] if ext else '')  # 去掉点
        new_name = new_name.replace('{PARENT}', parent)
        
        # 如果模式中没有扩展名，添加原扩展名
        if not new_name.endswith(ext) and ext:
            new_name += ext
        
        return new_name
    
    def execute_rename(self, operations, dry_run=False):
        """执行重命名操作"""
        if dry_run:
            print("预览模式 - 不会实际重命名文件")
        
        success_count = 0
        failed_count = 0
        
        print(f"\n开始{'预览' if dry_run else '执行'}重命名操作:")
        print("-" * 80)
        
        for op in operations:
            old_path = op['old_path']
            new_path = op['new_path']
            
            print(f"{old_path.name} -> {new_path.name}")
            
            if not dry_run:
                try:
                    # 检查新文件是否已存在
                    if new_path.exists():
                        print(f"  警告: {new_path.name} 已存在，跳过")
                        failed_count += 1
                        continue
                    
                    old_path.rename(new_path)
                    success_count += 1
                    print(f"  成功")
                    
                except (OSError, PermissionError) as e:
                    print(f"  失败: {e}")
                    failed_count += 1
            else:
                success_count += 1  # 预览模式都算成功
        
        print("-" * 80)
        
        if dry_run:
            print(f"预览完成: {success_count} 个文件将重命名")
        else:
            print(f"操作完成: {success_count} 成功, {failed_count} 失败")
        
        return success_count, failed_count
    
    def rename_by_pattern(self, file_pattern, new_name_pattern, 
                         recursive=False, start_index=1, dry_run=False):
        """按模式重命名文件"""
        # 查找文件
        files = self.find_files(file_pattern, recursive)
        
        if not files:
            print(f"未找到匹配模式 '{file_pattern}' 的文件")
            return 0, 0
        
        print(f"找到 {len(files)} 个匹配文件")
        
        # 预览操作
        operations = self.preview_rename(files, new_name_pattern, start_index)
        
        # 显示预览
        print("\n重命名预览:")
        print("-" * 60)
        for i, op in enumerate(operations[:10], 1):  # 只显示前10个
            print(f"{i:3d}. {op['old_name']} -> {op['new_name']}")
        
        if len(operations) > 10:
            print(f"... 还有 {len(operations) - 10} 个文件")
        
        print("-" * 60)
        
        # 确认
        if not dry_run:
            confirm = input(f"\n确认重命名 {len(files)} 个文件？(yes/no): ").strip().lower()
            if confirm != 'yes':
                print("操作已取消")
                return 0, 0
        
        # 执行重命名
        return self.execute_rename(operations, dry_run)

def main():
    parser = argparse.ArgumentParser(description="批量重命名文件")
    parser.add_argument("pattern", help="文件匹配模式（如: *.jpg, image_*.png）")
    parser.add_argument("new_pattern", help="新文件名模式（如: photo_{INDEX}.jpg, {YYYY}-{MM}-{DD}_{INDEX}{EXT}）")
    parser.add_argument("--directory", "-d", default=".", help="目标目录")
    parser.add_argument("--recursive", "-r", action="store_true", help="递归搜索子目录")
    parser.add_argument("--start-index", "-s", type=int, default=1, help="起始序号")
    parser.add_argument("--dry-run", action="store_true", help="预览模式，不实际重命名")
    
    args = parser.parse_args()
    
    # 可用变量说明
    print("可用变量:")
    print("  {YYYY} - 年, {MM} - 月, {DD} - 日")
    print("  {HH} - 时, {mm} - 分, {SS} - 秒")
    print("  {INDEX} - 3位序号(001), {INDEX1} - 普通序号(1)")
    print("  {STEM} - 原文件名（不含扩展名）")
    print("  {EXT} - 扩展名（不含点）")
    print("  {PARENT} - 父目录名")
    print()
    
    renamer = BatchRenamer(args.directory)
    success, failed = renamer.rename_by_pattern(
        args.pattern,
        args.new_pattern,
        args.recursive,
        args.start_index,
        args.dry_run
    )
    
    if args.dry_run:
        print(f"\n预览完成，使用 --dry-run 参数查看效果")
        print(f"去掉 --dry-run 参数实际执行重命名")
    else:
        print(f"\n操作完成: {success} 成功, {failed} 失败")

if __name__ == "__main__":
    main()