# 文件整理助手专业版 - 安装指南

## 📦 安装方式

### 方式1：直接使用（推荐）
1. 下载整个 `file-organizer-pro-package` 文件夹
2. 进入文件夹：`cd file-organizer-pro-package`
3. 直接运行脚本（需要Python环境）

### 方式2：集成到OpenClaw
1. 将文件夹复制到OpenClaw技能目录：
   ```
   cp -r file-organizer-pro-package ~/.openclaw/skills/
   ```
2. 或在工作空间中使用

### 方式3：作为独立工具
1. 只复制 `scripts/` 目录中的脚本
2. 添加到系统PATH或创建快捷方式

## 🔧 系统要求

### 必需
- **Python 3.8+** - 脚本运行环境
- **操作系统** - Windows 10+, macOS 10.14+, Linux

### 可选依赖
```bash
# 安装send2trash（安全删除到回收站）
pip install send2trash

# 安装其他依赖（如果有）
pip install -r requirements.txt
```

## 🚀 快速开始

### Windows
```powershell
# 进入技能目录
cd file-organizer-pro-package

# 运行整理脚本
python scripts\organize_by_type.py

# 清理临时文件（预览模式）
python scripts\clean_temporary.py --dry-run

# 批量重命名图片
python scripts\batch_rename.py "*.jpg" "photo_{INDEX}.jpg" --dry-run
```

### macOS/Linux
```bash
# 进入技能目录
cd file-organizer-pro-package

# 运行整理脚本
python3 scripts/organize_by_type.py

# 清理临时文件（预览模式）
python3 scripts/clean_temporary.py --dry-run

# 批量重命名图片
python3 scripts/batch_rename.py "*.jpg" "photo_{INDEX}.jpg" --dry-run
```

## 📁 文件结构

```
file-organizer-pro-package/
├── SKILL.md                    # 技能文档
├── INSTALL.md                  # 本安装指南
├── README.md                   # 使用说明
├── scripts/                    # 脚本目录
│   ├── organize_by_type.py     # 按类型整理
│   ├── clean_temporary.py      # 清理临时文件
│   ├── find_duplicates.py      # 查找重复文件
│   └── batch_rename.py         # 批量重命名
└── references/                 # 参考文档
    ├── file_types.md           # 文件类型参考
    ├── usage_guide.md          # 使用指南
    └── config_example.yaml     # 配置文件示例
```

## ⚙️ 配置说明

### 1. 基本配置
编辑 `references/config_example.yaml` 为 `config.yaml` 并修改配置。

### 2. 环境变量
```bash
# 设置默认工作目录
export FILE_ORG_DIR="~/Documents"

# 设置日志级别
export LOG_LEVEL="info"
```

### 3. 快捷方式创建
**Windows:**
```powershell
# 创建桌面快捷方式
$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$Home\Desktop\文件整理.lnk")
$Shortcut.TargetPath = "python"
$Shortcut.Arguments = "scripts\organize_by_type.py"
$Shortcut.WorkingDirectory = "C:\path\to\file-organizer-pro-package"
$Shortcut.Save()
```

**macOS/Linux:**
```bash
# 创建别名
echo 'alias fileorg="cd /path/to/file-organizer-pro-package && python3 scripts/organize_by_type.py"' >> ~/.bashrc
source ~/.bashrc
```

## 🔍 验证安装

运行测试命令验证安装：

```bash
# 显示帮助信息
python scripts/organize_by_type.py --help

# 测试文件分类
python scripts/organize_by_type.py --dry-run

# 测试临时文件清理
python scripts/clean_temporary.py --dry-run
```

如果看到帮助信息且没有错误，说明安装成功。

## 🆘 常见问题

### Q1: Python未找到
**A:** 安装Python 3.8+，或使用 `python3` 命令

### Q2: 模块导入错误
**A:** 安装缺失模块：`pip install send2trash`

### Q3: 权限被拒绝
**A:** 使用管理员权限运行，或检查文件权限

### Q4: 脚本无法执行
**A:** 确保脚本有执行权限：`chmod +x scripts/*.py`

## 📞 支持

如有问题：
1. 查看 `references/usage_guide.md`
2. 检查脚本的 `--help` 信息
3. 联系开发者

**版本:** 1.0.0  
**更新日期:** 2026-03-10