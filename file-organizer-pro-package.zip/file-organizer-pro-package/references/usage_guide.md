# 文件整理助手使用指南

## 📖 目录
1. [快速开始](#快速开始)
2. [功能详解](#功能详解)
3. [使用示例](#使用示例)
4. [高级技巧](#高级技巧)
5. [故障排除](#故障排除)

## 🚀 快速开始

### 安装依赖
```bash
# 安装Python依赖（如果需要）
pip install send2trash
```

### 基本使用
```bash
# 查看帮助
python organize_by_type.py --help

# 清理临时文件（预览模式）
python clean_temporary.py --dry-run

# 查找重复文件
python find_duplicates.py --min-size 100

# 批量重命名
python batch_rename.py "*.jpg" "photo_{INDEX}.jpg" --dry-run
```

## 🔧 功能详解

### 1. 按类型整理 (`organize_by_type.py`)
将文件按类型分类到不同文件夹：
- `images/` - 图片文件
- `documents/` - 文档文件
- `code/` - 代码文件
- `archives/` - 压缩文件
- `data/` - 数据文件
- `media/` - 媒体文件
- `other/` - 其他文件

**参数：**
- `--help` - 显示帮助
- 无参数时整理当前目录

### 2. 清理临时文件 (`clean_temporary.py`)
清理临时文件、缓存文件、备份文件等。

**参数：**
- `directory` - 目标目录（默认: 当前目录）
- `--days N` - 清理N天前的文件（默认: 30）
- `--dry-run` - 预览模式，不实际删除
- `--execute` - 实际执行删除

### 3. 查找重复文件 (`find_duplicates.py`)
基于文件内容和哈希值查找重复文件。

**参数：**
- `directory` - 目标目录（默认: 当前目录）
- `--min-size N` - 最小文件大小(KB)（默认: 10）
- `--no-recursive` - 不递归扫描
- `--generate-script` - 生成清理脚本

### 4. 批量重命名 (`batch_rename.py`)
按模式批量重命名文件。

**参数：**
- `pattern` - 文件匹配模式（如: `*.jpg`）
- `new_pattern` - 新文件名模式
- `--directory DIR` - 目标目录
- `--recursive` - 递归搜索
- `--start-index N` - 起始序号
- `--dry-run` - 预览模式

## 📋 使用示例

### 示例1：整理下载文件夹
```bash
cd ~/Downloads
python organize_by_type.py
```

### 示例2：清理项目临时文件
```bash
cd my-project
python clean_temporary.py --days 7 --dry-run
# 检查预览结果后
python clean_temporary.py --days 7 --execute
```

### 示例3：查找并清理重复图片
```bash
cd photos
python find_duplicates.py --min-size 100 --generate-script
# 检查生成的脚本
cat cleanup_duplicates.sh
# 执行清理
bash cleanup_duplicates.sh
```

### 示例4：批量重命名照片
```bash
cd vacation_photos
python batch_rename.py "*.jpg" "vacation_{YYYY}{MM}{DD}_{INDEX}.jpg" --dry-run
# 检查预览后
python batch_rename.py "*.jpg" "vacation_{YYYY}{MM}{DD}_{INDEX}.jpg"
```

## 🎯 高级技巧

### 1. 组合使用
```bash
# 先整理，再清理，最后重命名
python organize_by_type.py
python clean_temporary.py --days 30 --execute
cd images
python batch_rename.py "*.jpg" "{YYYY}-{MM}-{DD}_{INDEX}.jpg"
```

### 2. 自定义文件类型
编辑 `organize_by_type.py` 中的 `categories` 字典，添加自定义文件类型：

```python
categories = {
    "images": [".jpg", ".jpeg", ".png", ".gif"],
    "documents": [".pdf", ".doc", ".docx", ".txt"],
    # 添加自定义类型
    "my-files": [".myext", ".data"],
}
```

### 3. 安全删除
默认使用 `send2trash` 库，文件会移动到回收站而不是永久删除。如需永久删除，修改代码：

```python
# 替换 send2trash 为 os.remove
import os
os.remove(str(file_path))
```

### 4. 定时任务
使用cron或任务计划程序定期整理：

```bash
# Linux/Mac: 每周日整理下载文件夹
0 2 * * 0 cd ~/Downloads && python /path/to/organize_by_type.py

# Windows: 创建计划任务
```

## ⚠️ 注意事项

### 1. 权限问题
- 确保对目标目录有读写权限
- 系统文件可能需要管理员权限

### 2. 文件冲突
- 重命名时检查文件是否已存在
- 移动文件时避免覆盖重要文件

### 3. 性能考虑
- 大量文件时建议分批处理
- 大文件哈希计算可能较慢

### 4. 备份建议
重要操作前建议备份：
```bash
# 创建备份
cp -r my-project my-project-backup
# 或使用压缩备份
tar -czf backup.tar.gz my-project
```

## 🆘 故障排除

### 问题1：脚本无法执行
**症状：** `python: command not found`
**解决：** 安装Python 3.8+，或使用 `python3` 命令

### 问题2：导入错误
**症状：** `ModuleNotFoundError: No module named 'send2trash'`
**解决：** `pip install send2trash`

### 问题3：权限被拒绝
**症状：** `PermissionError: [Errno 13] Permission denied`
**解决：** 使用管理员权限运行，或检查文件权限

### 问题4：处理速度慢
**症状：** 大量文件时处理缓慢
**解决：** 
- 减少同时处理的文件数量
- 增加 `--min-size` 参数忽略小文件
- 关闭递归扫描 (`--no-recursive`)

### 问题5：误删文件
**症状：** 重要文件被删除
**解决：**
- 检查回收站
- 从备份恢复
- 下次使用 `--dry-run` 预览

## 📞 支持与反馈

如有问题或建议：
1. 检查本文档的故障排除部分
2. 查看脚本的 `--help` 信息
3. 联系开发者

**版本：** 1.0.0  
**更新日期：** 2026-03-10