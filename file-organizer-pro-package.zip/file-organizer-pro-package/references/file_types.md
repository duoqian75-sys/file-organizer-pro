# 文件类型参考

## 常见文件类型分类

### 图片文件
- .jpg, .jpeg - JPEG图像
- .png - PNG图像
- .gif - GIF动画
- .bmp - 位图
- .svg - 矢量图
- .webp - WebP图像

### 文档文件
- .pdf - PDF文档
- .doc, .docx - Word文档
- .txt - 纯文本
- .md - Markdown文档
- .rtf - 富文本

### 代码文件
- .py - Python代码
- .js - JavaScript代码
- .html - HTML文件
- .css - CSS样式表
- .json - JSON数据
- .xml - XML文件
- .yml, .yaml - YAML配置

### 压缩文件
- .zip - ZIP压缩
- .rar - RAR压缩
- .7z - 7-Zip压缩
- .tar - Tar归档
- .gz - Gzip压缩

### 数据文件
- .csv - CSV数据
- .xlsx, .xls - Excel表格
- .db - 数据库文件
- .sqlite - SQLite数据库

### 媒体文件
- .mp3 - MP3音频
- .mp4 - MP4视频
- .avi - AVI视频
- .mov - QuickTime视频
- .wav - WAV音频

## 临时文件
- .tmp - 临时文件
- .log - 日志文件
- .cache - 缓存文件
- ~ - 备份文件（如file.txt~）