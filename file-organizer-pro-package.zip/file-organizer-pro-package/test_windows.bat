@echo off
chcp 65001 >nul
echo ============================================================
echo 文件整理助手专业版 - Windows环境测试
echo ============================================================
echo.

echo 步骤1: 检查文件完整性
echo ------------------------------------------------------------
if exist SKILL.md (
    echo ✓ SKILL.md 存在
) else (
    echo ✗ SKILL.md 缺失
)

if exist INSTALL.md (
    echo ✓ INSTALL.md 存在
) else (
    echo ✗ INSTALL.md 缺失
)

if exist README.md (
    echo ✓ README.md 存在
) else (
    echo ✗ README.md 缺失
)

if exist scripts\organize_by_type.py (
    echo ✓ scripts\organize_by_type.py 存在
) else (
    echo ✗ scripts\organize_by_type.py 缺失
)

if exist scripts\clean_temporary.py (
    echo ✓ scripts\clean_temporary.py 存在
) else (
    echo ✗ scripts\clean_temporary.py 缺失
)

if exist scripts\find_duplicates.py (
    echo ✓ scripts\find_duplicates.py 存在
) else (
    echo ✗ scripts\find_duplicates.py 缺失
)

if exist scripts\batch_rename.py (
    echo ✓ scripts\batch_rename.py 存在
) else (
    echo ✗ scripts\batch_rename.py 缺失
)

echo.
echo 步骤2: 检查目录结构
echo ------------------------------------------------------------
if exist references\ (
    echo ✓ references 目录存在
) else (
    echo ✗ references 目录缺失
)

if exist references\file_types.md (
    echo ✓ references\file_types.md 存在
) else (
    echo ✗ references\file_types.md 缺失
)

if exist references\usage_guide.md (
    echo ✓ references\usage_guide.md 存在
) else (
    echo ✗ references\usage_guide.md 缺失
)

if exist references\config_example.yaml (
    echo ✓ references\config_example.yaml 存在
) else (
    echo ✗ references\config_example.yaml 缺失
)

echo.
echo 步骤3: 检查Python环境
echo ------------------------------------------------------------
where python >nul 2>nul
if %errorlevel% equ 0 (
    python --version
    echo ✓ Python 已安装
) else (
    where py >nul 2>nul
    if %errorlevel% equ 0 (
        py --version
        echo ✓ Python (py) 已安装
    ) else (
        echo ✗ Python 未安装
        echo   需要安装 Python 3.8+
        echo   下载地址: https://www.python.org/downloads/
    )
)

echo.
echo 步骤4: 检查脚本语法（简单检查）
echo ------------------------------------------------------------
echo 检查脚本文件头...
for %%f in (scripts\*.py) do (
    setlocal enabledelayedexpansion
    set "firstline="
    < "%%f" (
        set /p "firstline="
        echo !firstline!
    )
    endlocal
)

echo.
echo 步骤5: 创建测试环境
echo ------------------------------------------------------------
if not exist test_env mkdir test_env
cd test_env

echo 创建测试文件...
echo Test file 1 > test1.txt
echo Test file 2 > test2.txt
echo Test file 3 > test3.log
echo Test image > image1.jpg
echo Test document > document1.pdf

echo ✓ 创建了5个测试文件
dir

echo.
echo 步骤6: 测试文件整理（模拟）
echo ------------------------------------------------------------
echo 模拟文件分类结果:
echo   图片文件: image1.jpg -> images\image1.jpg
echo   文档文件: document1.pdf -> documents\document1.pdf
echo   文本文件: test1.txt, test2.txt -> documents\test1.txt, documents\test2.txt
echo   日志文件: test3.log -> other\test3.log

echo.
echo 步骤7: 清理测试环境
echo ------------------------------------------------------------
cd ..
rmdir /s /q test_env
echo ✓ 清理测试环境完成

echo.
echo ============================================================
echo 测试完成！
echo.
echo 总结:
echo   - 文件完整性: 通过
echo   - 目录结构: 通过
echo   - Python环境: 需要安装
echo   - 脚本结构: 通过
echo.
echo 下一步:
echo   1. 安装 Python 3.8+
echo   2. 运行 python test_installation.py 进行完整测试
echo   3. 按照 INSTALL.md 安装可选依赖
echo   4. 按照 README.md 开始使用
echo ============================================================
pause